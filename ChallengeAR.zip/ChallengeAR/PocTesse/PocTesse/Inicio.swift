//
//  Inicio.swift
//  PocTesse
//
//  Created by Mariana Abraão on 02/06/22.
//

import Foundation
import SwiftUI

struct Inicio : View {
    var body: some View {
      
        ZStack {
           
            Color("BGColor").ignoresSafeArea()
            VStack{
                Spacer()
                Button(action: {
                }){
                    Image("fundo")
                    
                }
                .padding(.horizontal)
                .padding(.vertical)
                .scaledToFit()
                Spacer()
            }
            .padding(.horizontal)
            .padding(.vertical)
            
        }
       

            }
    }











struct Inicio_Preview : PreviewProvider {
    static var previews: some View {
        Inicio()
    }
}
