//
//  Menuview.swift
//  PocTesse
//
//  Created by Mariana Abraão on 02/06/22.
//

import SwiftUI

struct Menuview: View {
    var body: some View {
        ZStack {
           
            Color("BGColor").ignoresSafeArea()
            VStack{
                Spacer()
                Button(action: {
                }){
                    Image("instrucao")
                        .padding(.horizontal)
                        .padding(.vertical)
                        .scaledToFit()
                    
                }
                .padding(.horizontal)
                .padding(.vertical)
                .scaledToFit()
                Spacer()
            }
            .padding(.horizontal)
            .padding(.vertical)
            
        }
    }
}

struct Menuview_Previews: PreviewProvider {
    static var previews: some View {
        Menuview()
    }
}
