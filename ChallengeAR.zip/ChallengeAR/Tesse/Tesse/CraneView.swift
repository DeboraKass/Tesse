//
//  CraneView.swift
//  Tesse
//
//  Created by Mariana Abraão on 07/06/22.
//

import SwiftUI
import RealityKit

struct CraneView : View {
    
    @Binding var showModalARCrane: Bool
    
    var body: some View {
        ZStack(alignment: .topTrailing){
            ARViewContainerTree().edgesIgnoringSafeArea(.all)
            
            
            Button {
                showModalARCrane = false
            } label: {
                Text("Fechar")
            }
            .padding()
            .frame(width: 100, height: 30)
            .background(Color.yellow)
            .cornerRadius(90)
            .padding(.horizontal)
            .foregroundColor(.black)

            
            
        }
        
        
    }
}

struct ARViewContainerTree: UIViewRepresentable {
    func makeUIView(context: Context) -> ARView {
        
        let arView = ARView(frame: .zero)
        
        // Load the "Box" scene from the "Experience" Reality File
        let scene1Anchor = try! Experience.loadScene1()
        
        // Add the box anchor to the scene
        arView.scene.anchors.append(scene1Anchor)
        
        return arView
        
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {}
    
}

#if DEBUG
struct ContentView_PreviewsTree : PreviewProvider {
    static var previews: some View {
        CraneView(showModalARCrane: .constant(true))
    }
}
#endif
