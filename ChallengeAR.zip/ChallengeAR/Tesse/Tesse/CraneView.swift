//
//  CraneView.swift
//  Tesse
//
//  Created by Mariana Abraão on 07/06/22.
//

import SwiftUI
import RealityKit

struct CraneView : View {
    var body: some View {
        ARViewContainerTree().edgesIgnoringSafeArea(.all)
    }
}

struct ARViewContainerTree: UIViewRepresentable {
    func makeUIView(context: Context) -> ARView {
        
        let arView = ARView(frame: .zero)
        
        // Load the "Box" scene from the "Experience" Reality File
        let scene1Anchor = try! Experience.loadScene1()
        
        // Add the box anchor to the scene
        arView.scene.anchors.append(scene1Anchor)
        
        return arView
        
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {}
    
}

#if DEBUG
struct ContentView_PreviewsTree : PreviewProvider {
    static var previews: some View {
        CraneView()
    }
}
#endif
