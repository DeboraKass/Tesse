//
//  ContentView.swift
//  Tesse
//
//  Created by Mariana Abraão on 02/06/22.
//

import SwiftUI
import RealityKit

struct ContentView : View {
    
    @Binding var showModalARContent: Bool

    
    var body: some View {
        ZStack(alignment: .topTrailing){
            
            ARViewContainer().edgesIgnoringSafeArea(.all)
            
            Button {
                showModalARContent = false
            } label: {
                Text("Fechar")
            }
            .padding()
            .frame(width: 100, height: 30)
            .background(Color.yellow)
            .cornerRadius(90)
            .padding(.horizontal)
            .foregroundColor(.black)
        }
        
    }
}

struct ARViewContainer: UIViewRepresentable {
    func makeUIView(context: Context) -> ARView {
        
        let arView = ARView(frame: .zero)
        
        // Load the "Box" scene from the "Experience" Reality File
        let boxAnchor = try! Experience.loadBox()
        
        // Add the box anchor to the scene
        arView.scene.anchors.append(boxAnchor)
        
        return arView
        
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {}
    
}

#if DEBUG
struct ContentView_Previews : PreviewProvider {
    static var previews: some View {
        ContentView(showModalARContent: .constant(true))
    }
}
#endif
