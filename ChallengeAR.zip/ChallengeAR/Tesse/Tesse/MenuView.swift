//
//  MenuView.swift
//  Tesse
//
//  Created by Mariana Abraão on 02/06/22.
//

import SwiftUI

struct MenuView: View {
    
    @State var showModalPrism = false
    @State var showModalSeta = false
    @State public var showModalCrane = false
    
    
    var body: some View {
        
        ZStack {
            
            Color("BGColor").ignoresSafeArea()
            VStack{
                Spacer()
                
                    Image("intrucao")
                        .offset(x: 25)
                
                .padding(.horizontal)
                .padding(.vertical)
                .scaledToFit()
                Spacer()
                
                
                ScrollView(.horizontal) {
                    
                    
                    HStack{
                        Text("")
                            .foregroundColor(.white)
                            .font(.largeTitle)
                            .frame(width: 50, height: 200)
                        
                        Button(action: {
                            showModalPrism = true
                        }){
                            Image("PrismImage")
                                .resizable()
                                .frame(width: 323, height: 555)
                        }
                        .sheet(isPresented: $showModalPrism) {
                            
                            ModalPrismView()
                        }
                        
                        
                        
                        Button(action: {
                            showModalSeta = true
                        }){
                            Image("SetasCard")
                                .resizable()
                                .frame(width: 323, height: 555)
                        }
                        .sheet(isPresented: $showModalSeta) {
                            
                            ModalSetaView()
                        }
                        
                        
                        
                        Button(action: {
                            showModalCrane = true
                        }){
                            Image("CraneFinal")
                                .resizable()
                                .frame(width: 323, height: 555)
                        }
                        .sheet(isPresented: $showModalCrane) {
                            
                            ModalCraneView()
                        }
                        Text("")
                            .foregroundColor(.white)
                            .font(.largeTitle)
                            .frame(width: 50, height: 200)
                        
                        
                        
                        
                        
                    }
                    
                }
                .frame( alignment: .topLeading)
                
                
            }
            .padding(.horizontal)
            .padding(.vertical)
            .offset(y: -45)
            
        }
        
        
    }
}


struct ModalPrismView: View{
    @State var showModalAr = false
    
    var body: some View{
        ZStack{
            Color("PrismColor").ignoresSafeArea()
            VStack {
                HStack {
                    Spacer()
                    Spacer()
                    Spacer()
                    Spacer()
                    Spacer()
                    Text("Prism")
                        .fontWeight(.semibold)
                    Spacer()
                    Button(action: {
                        showModalAr = true
                    }){
                        Image(systemName: "cube")
                            .foregroundColor(.black)
                        Text("AR")
                            .foregroundColor(.black)
                    }
                    .fullScreenCover(isPresented: $showModalAr) {
                        PrismView(showModalAR: $showModalAr)
                    }
                    .frame(width: 100, height: 30)
                    .background(Color.yellow)
                    .cornerRadius(90)
                    .padding(.horizontal)
                }
                .padding()
                
                Spacer()
                //Colocar Cards aqui
                
                ScrollView{
                   GambiarraTres()
                    GambiarraQuatro()
                  
                   
                    
                }
            }
        }
    }
}




struct ModalSetaView: View{
    
    @State var showModalArDois = false
    
    var body: some View{
        ZStack{
            Color("SetaColor").ignoresSafeArea()
            
            VStack{
                HStack{
                    Spacer()
                    
                    Spacer()
                    
                    Spacer()
                    
                    Spacer()
                    
                    Spacer()
                    
                    Text("Setas")
                        .fontWeight(.semibold)
                    
                    Spacer()
                    
                    
                    Button(action: {
                        showModalArDois = true
                    }){
                        
                        
                        Image(systemName: "cube")
                            .foregroundColor(.black)
                        Text("AR")
                            .foregroundColor(.black)
                    }
                    .fullScreenCover(isPresented: $showModalArDois) {
                        
                        ContentView(showModalARContent: $showModalArDois)
                    }
                    
                    .frame(width: 100, height: 30)
                    .background(Color.yellow)
                    .cornerRadius(90)
                    .padding()
                    
                    
                }
                .padding()
                
                Spacer()
                //Colocar Cards aqui
                
                ScrollView{
                    GambiarraUm()
                    GambiarraDois()
                                        
                }
            }
        }
    }
}

struct ModalCraneView: View{
    
    @State var showModalArTres = false
    
    var body: some View{
        ZStack{
            Color("CraneColor").ignoresSafeArea()
            
            VStack{
                HStack{
                    Spacer()
                    
                    Spacer()
                    
                    Spacer()
                    
                    Spacer()
                    
                    Spacer()
                    
                    Text("Crane")
                        .fontWeight(.semibold)
                    
                    Spacer()
                    
                    
                    Button(action: {
                        showModalArTres = true
                    }){
                        
                        
                        Image(systemName: "cube")
                            .foregroundColor(.black)
                        Text("AR")
                            .foregroundColor(.black)
                    }
                    .fullScreenCover(isPresented: $showModalArTres) {
                        
                        CraneView(showModalARCrane: $showModalArTres)
                        
                        
                        
                    }
                    
                    .frame(width: 100, height: 30)
                    .background(Color.yellow)
                    .cornerRadius(90)
                    .padding()
                    
                    
                }
                .padding()
                
                Spacer()
                //Colocar Cards aqui
                
                ScrollView{
                    Image("CraneUm")
                        .resizable()
                        .frame(width: 358, height: 205)
                    
                    
                    Image("Crane2")
                        .resizable()
                        .frame(width: 358, height: 205)
                    
                    
                    Image("Crane3")
                        .resizable()
                        .frame(width: 358, height: 290)
                    
                    Image("Crane4")
                        .resizable()
                        .frame(width: 358, height: 205)
                    
                    
                    Image("Crane5")
                        .resizable()
                        .frame(width: 358, height: 290)
                    
                    
                    Image("Crane6")
                        .resizable()
                        .frame(width: 358, height: 290)
                    
                    
                    Image("Crane7")
                        .resizable()
                        .frame(width: 358, height: 290)
                    
                    
                    Image("Crane8")
                        .resizable()
                        .frame(width: 358, height: 290)
                    
                    
                }
            }
        }
    }
}

//Gabiarra da SETAS AQUI---------------------------------

struct GambiarraUm: View{
    var body: some View{
    
        Image("Seta1")
            .resizable()
            .frame(width: 358, height: 205)
        
        Image("Seta2")
            .resizable()
            .frame(width: 358, height: 205)
        
        Image("Seta3")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Seta4")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Seta5")
            .resizable()
            .frame(width: 358, height: 205)
        
        Image("Seta6")
            .resizable()
            .frame(width: 358, height: 205)
        
        Image("Seta7")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Seta8")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Seta9")
            .resizable()
            .frame(width: 358, height: 205)
        
        Image("Seta10")
            .resizable()
            .frame(width: 358, height: 290)
        
    
    }
    
}

struct GambiarraDois: View{
    var body: some View{
    
        Image("Seta11")
            .resizable()
            .frame(width: 358, height: 205)
        
        Image("Seta12")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Seta13")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Seta14")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Seta15")
            .resizable()
            .frame(width: 358, height: 205)
        
        Image("Seta16")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Seta17")
            .resizable()
            .frame(width: 358, height: 205)
        
        Image("Seta18")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Seta19")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Seta20")
            .resizable()
            .frame(width: 358, height: 290)
        
    
    }
    
}


//Gabiarra da PRISM AQUI---------------------------------


struct GambiarraTres: View{
    var body: some View{
    
        Image("Passo1")
            .resizable()
            .frame(width: 358, height: 205)
        
        Image("Passo2")
            .resizable()
            .frame(width: 358, height: 205)
        
        Image("Passo3")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Passo4")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Passo5")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Passo6")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Passo7")
            .resizable()
            .frame(width: 358, height: 205)
        
        Image("Passo8")
            .resizable()
            .frame(width: 358, height: 205)
        
        Image("Passo9")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Passo10")
            .resizable()
            .frame(width: 358, height: 290)
        
    
    }
    
}

struct GambiarraQuatro: View{
    var body: some View{
    
        Image("Passo11")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Passo12")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Passo13")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Passo14")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Passo15")
            .resizable()
            .frame(width: 358, height: 290)
        
        Image("Passo16")
            .resizable()
            .frame(width: 358, height: 205)
        
       
        
    
    }
    
}




struct MenuView_Previews: PreviewProvider {
    static var previews: some View {
        MenuView()
    }
}
