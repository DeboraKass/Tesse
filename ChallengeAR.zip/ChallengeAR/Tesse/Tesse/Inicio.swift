//
//  Inicio.swift
//  Tesse
//
//  Created by Mariana Abraão on 02/06/22.
//
import Foundation
import SwiftUI


struct Inicio: View {
    var body: some View {
        NavigationView{
            ZStack {
               
                Color("BGColor").ignoresSafeArea()
                VStack{
                    
                    NavigationLink(destination: MenuView().navigationBarBackButtonHidden(true)) {
                        Image("Fundo")
                            .resizable()
                                .frame(width: 425, height: 820)
                                .offset(y: -50)
                                
                    }
                            
                }
                .padding(.horizontal)
                .padding(.vertical)
               
            }
           
           
        }
        
        //Talvez nao funcione isso aqui
        
    }
}

struct Inicio_Previews: PreviewProvider {
    static var previews: some View {
        Inicio()
    }
}
