//
//  PrismView.swift
//  Tesse
//
//  Created by Mariana Abraão on 07/06/22.
//
import SwiftUI
import RealityKit

struct PrismView : View {
    @Binding var showModalAR: Bool
    
    var body: some View {
        ZStack(alignment: .topTrailing){
            ARViewContainerDois().edgesIgnoringSafeArea(.all)
            
            Button {
                showModalAR = false
            } label: {
                Text("Fechar")
            }
            .padding()
            .frame(width: 100, height: 30)
            .background(Color.yellow)
            .cornerRadius(90)
            .padding(.horizontal)
            .foregroundColor(.black)

        }
        
    }
}

struct ARViewContainerDois: UIViewRepresentable {
    func makeUIView(context: Context) -> ARView {
        
        let arView = ARView(frame: .zero)
        
        // Load the "Box" scene from the "Experience" Reality File
        let sceneAnchor = try! Experience.loadScene()
        
        // Add the box anchor to the scene
        arView.scene.anchors.append(sceneAnchor)
        
        return arView
        
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {}
    
}

#if DEBUG
struct ContentView_PreviewsDois : PreviewProvider {
    static var previews: some View {
        PrismView(showModalAR: .constant(true))
    }
}
#endif
