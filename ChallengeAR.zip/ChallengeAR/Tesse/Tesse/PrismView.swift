//
//  PrismView.swift
//  Tesse
//
//  Created by Mariana Abraão on 07/06/22.
//
import SwiftUI
import RealityKit

struct PrismView : View {
    var body: some View {
        ARViewContainerDois().edgesIgnoringSafeArea(.all)
    }
}

struct ARViewContainerDois: UIViewRepresentable {
    func makeUIView(context: Context) -> ARView {
        
        let arView = ARView(frame: .zero)
        
        // Load the "Box" scene from the "Experience" Reality File
        let sceneAnchor = try! Experience.loadScene()
        
        // Add the box anchor to the scene
        arView.scene.anchors.append(sceneAnchor)
        
        return arView
        
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {}
    
}

#if DEBUG
struct ContentView_PreviewsDois : PreviewProvider {
    static var previews: some View {
        PrismView()
    }
}
#endif
